function MatingPool = MatingSelection(PopObj,FrontValue,r)
% Mating selection procedure of ad-MOEA
N = size(PopObj,1);

%% Binary tournament selection
Parent1   = randi(N,1,N);
Parent2   = randi(N,1,N);
MatingPool = zeros(1,N);

%% sum of normalized objectives
WSRANK           = F_WSRank(PopObj); 

%% Crowding distance
DistanceValue    = CrowdingDistance(PopObj,FrontValue);

%% Weighted Rank calculation
Ranks            = F_sortrank(FrontValue,WSRANK,DistanceValue,N);
WSR              = Ranks(:,1)*(1-r) + Ranks(:,2)*(r);  % Weighted Rank

for i = 1:N
    if  WSR(Parent1(i)) < WSR(Parent2(i))
        MatingPool(i) = Parent1(i);
    elseif  WSR(Parent1(i)) > WSR(Parent2(i))
        MatingPool(i) = Parent2(i);
    else
        if rand< 0.5
            MatingPool(i) = Parent1(i);
        else
            MatingPool(i) = Parent2(i);
        end
    end
end