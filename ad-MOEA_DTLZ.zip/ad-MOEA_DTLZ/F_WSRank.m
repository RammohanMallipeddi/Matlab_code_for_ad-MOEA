function WSRANK = F_WSRank(FunctionValue)

    [N,M] = size(FunctionValue);


        fmaximum         = repmat(max(FunctionValue,[],1),N,1);
        fminimum         = repmat(min(FunctionValue,[],1),N,1);
        FunctionValue    = (FunctionValue-fminimum)./(fmaximum-fminimum);
        [WSRANK]          = sum(FunctionValue,2);
    
end