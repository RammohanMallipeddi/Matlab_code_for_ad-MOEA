% Matlab code:paper: An Evolutionary Algorithm for Multi and Many-Objective Optimization
% With Adaptive Mating and Environmental Selection
% Authors: Vikas Palakonda;Rammohan Mallipeddi

% Email: vikas.11475@gmail.com; mallipeddi.ram@gmail.com

clc;format compact;tic;
%-----------------------------------------------------------------------------------------
% Problem Selection and Problem Paramaters
for Problem = 1 : 7
    
    for M =  2 : 2 : 10% number of objectives
        
        if Problem == 1 % DTLZ1
            K = 5;  % the parameter in DTLZ1
        elseif Problem == 2 || 3 || 4
            K = 10;  % the parameter in DTLZ2, DTLZ3, DTLZ4,
        elseif Problem == 5 || 6
            K = 10;  % the parameter in DTLZ5, DTLZ6
        elseif Problem == 7 % DTLZ7
            K = 20;  % the parameter in DTLZ7
        end
        D = M + K - 1;
        
        MinValue   = zeros(1,D);
        MaxValue   = ones(1,D);
        %-----------------------------------------------------------------------------------------
        % Algorithm parameters
        
        if Problem == 1
            Generations = 700;	 % number of iterations
        elseif Problem == 3
            Generations = 1000;
        else
            Generations = 250;
        end
        
        if M == 2
            N = 100;            % population size
        elseif M == 4
            N = 120;
        elseif M == 6
            N = 132;
        elseif M == 8
            N = 156;
        elseif M == 10
            N = 276;
        end
        
        Runs = 30;
        Boundary = [MaxValue;MinValue];
        %-----------------------------------------------------------------------------------------
        for run = 1 : Runs
            tic;
            % initialize the population
            Population                    = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue                 = F_DTLZ(Population,Problem,M,K);     % calculate the objective function values
            FrontValue                    = ENS(FunctionValue,'all');      % non-dominated sort, and return the front number of each solution
            DistanceValue                 = CrowdingDistance(FunctionValue,FrontValue);
            r                             = 1;
            %-----------------------------------------------------------------------------------------
            % start iterations
            for Gene = 1 : Generations
                MatingPool          = MatingSelection(FunctionValue,FrontValue,r);
                Offspring           = F_operator(Population(MatingPool',:),Boundary);
                NewF                = F_DTLZ(Offspring,Problem,M,K);      % calculate the objective function values 
                
                %% combine the two populations
                Population          = [Population;Offspring];             
                FunctionValue       = [FunctionValue;NewF];           
                
                %% Environmental selection
                [Population,FunctionValue,FrontValue,r] = EnvSel(Population,FunctionValue,N,r);
                 Gene
            end
            F_output(Population,toc,'ad-MOEA_DTLZ',Problem,M,K,run);
        end
    end
end
